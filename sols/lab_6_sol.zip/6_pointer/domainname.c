#include <stdio.h>

char* getdomain(char* p){
    // Your code here.
    // Use single quotations around a character to represent a char constant.
    // 'c' represents a char constant. 

    int i = 0;
    while(p[i] != '@'){
        i++; 
    }
    return &p[i+1];
}

void main(){
    // In C, a string is a char array (see the last slide of the previous lecture).     
    char email[] = "sl9885@bristol.ac.uk";
    printf("---------some tests----------\n");

    printf("%s\n", email); 
    // should print my email
    
    // print the first element in the char array
    printf("%c\n", email[0]); 
    // should print "s".

    //What will the following code print? try it yourself. 
    //Why do you see the output as shown?  
    //Hint: C knows where your string ends, see the last slides of the previous lecture.
    printf("%s\n", &email[7]); 

    // write your code in getdomain function, so that if I uncomment the following three lines
    // printf("\n---------test getdomain----------\n");
    char *t = getdomain(email);
    printf("%s \n", t);
    
    // It prints out the domain name after @ in my email. 
    // Change my email to your email, does it work? 
    // Chagne my email to abc@google.com, does it print out "google.com"? 
}