#include <stdio.h>

// What's the point of keeping "*elements private" and using method
// "get_elem"? Can't we just implement "get_elem" as a standalone function
// and make "*elements" public. 

// [1] If you call set_elem, get_elem etc before having defined
//     the constructor you will get a segmentation fault (or "core dumped")

// [2] Compilation warning "control may reach end of non-void function", 
//     what is that about?

class matrix{

  int num_rows;
  int num_cols;
  int *elements;
  
public: 

  matrix(int nrow, int ncol, int *elem){
    if (nrow <= 0 || ncol <= 0){
      printf("invalid dimensions!\n");
    }else{
      num_rows = nrow;
      num_cols = ncol;
      elements = elem;
    }
  }

  int get_elem(int i, int j){
     if (i < 0 || i >= num_rows || j < 0 || j >= num_cols){
       printf("invalid indices!\n");
     }else{
       return elements[i * num_cols + j];
     }
     // [2] add "return -1;" here.
  }
  
  /* [2] in "main" you type: 
  printf("oooo %d \n" , A.get_elem(10, 10));
  17

  printf("oooo %d \n" , printf("invalid indices!\n"));
  17 

  From cplusplus.com: int printf ( const char * format, ... )
  */
  
  void set_elem(int i, int j, int value){
    if (i < 0 || i >= num_rows || j < 0 || j >= num_cols){
      printf("invalid indices!\n");
    }else{
      elements[i * num_cols + j] = value;
    }
  }
  
  void add(matrix B){
    if (num_rows != B.num_rows || num_cols != B.num_cols){
      printf("invalid dimensions!\n");
    }else{
      for (int i = 0; i < num_rows; i++){
        for (int j = 0; j < num_cols; j++){
          set_elem(i, j, get_elem(i, j) + B.get_elem(i, j));
        }
      }
    }
  }
  
  void print(){
    for (int i = 0; i < num_rows; i++){
      for (int j = 0; j < num_cols; j++){
        printf("%d ", get_elem(i, j));
      }
      printf("\n");
    }
  }
  
};

int main(){  
  // prepare data in the stack memory
  int num_rows = 2;
  int num_cols = 3;
  
  int elementsA[] = {1, 2, 3, 4, 5, 6};
  int elementsB[] = {7, 8, 9, 10, 11, 12};
    
  // create two matrices, with constructor.
  matrix A(num_rows, num_cols, elementsA);
  matrix B(num_rows, num_cols, elementsB);
  
  printf("printing A\n");
  A.print();
  
  printf("\nprinting B\n");
  B.print();
  
  printf("--------------------\n");
  
  // test your setter and getter functions.
  printf("setting A(0, 0) to 9\n");
  A.set_elem(0, 0, 9);
  printf("printing A\n");
  A.print();
  printf("\n");
  
  // using the setter function but with invalid indices.
  printf("setting B(2, -2) to 100\n");
  B.set_elem(2, -2, 100);
  printf("printing B\n");
  B.print();
  printf("\n");
  
  // test your add function:
  printf("adding B to A\n");
  A.add(B);
  printf("printing A\n");
  A.print();
  printf("\n");

  // test your add function but with incompatible dimensions:
  int elementsC[] = {1, 2, 3, 4, 5, 6};
  matrix C(3, 2, elementsC);
  printf("adding C to A\n");
  A.add(C);
  printf("printing A\n");
  A.print(); // A should not change!
}
