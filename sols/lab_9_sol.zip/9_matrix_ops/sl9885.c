#include <stdio.h>
#include <stdlib.h>

// previous lab
// matrix structure definition
struct matrix {
    int numrows; // number of rows
    int numcols; // number of columns
    int *elements; // pointer to the elements stored in row-major order
};

// previous lab
// obtain the element at row i and column j
// input: matrix M, row i, column j
// output: element at row i and column j
int get_elem(struct matrix M, int i, int j){
    return M.elements[i*M.numcols + j];
}

// TODO: write the function set_elem
// assign value v to the element at row i and column j 
// input: matrix M, row i, column j, value v
// output: none
void set_elem(struct matrix M, int i, int j, int v){
    M.elements[i*M.numcols + j] = v;
}

// TODO: write a function that performs matrix multiplication
// input: matrix A, matrix B, matrix C
// It computes C = A*B
void mult(struct matrix A, struct matrix B, struct matrix C){
    //check if the number of columns of A is equal to the number of rows of B
    if(A.numcols != B.numrows){
        printf("Error: the number of columns of A is not equal to the number of rows of B\n");
        return;
    }
    //check if the number of rows of C is equal to the number of rows of A
    if(C.numrows != A.numrows){
        printf("Error: the number of rows of C is not equal to the number of rows of A\n");
        return;
    }
    //check if the number of columns of C is equal to the number of columns of B
    if(C.numcols != B.numcols){
        printf("Error: the number of columns of C is not equal to the number of columns of B\n");
        return;
    }

    int i, j, k;
    for (i = 0; i < A.numrows; i++){
        for (j = 0; j < B.numcols; j++){
            int sum = 0;
            for (k = 0; k < A.numcols; k++){
                sum += get_elem(A, i, k) * get_elem(B, k, j);
            }
            set_elem(C, i, j, sum);
        }
    }
}

// previous lab, printing matrix M
// input: matrix M
void print(struct matrix M){
    for (int i = 0; i < M.numrows; i ++){
        for (int j = 0; j < M.numcols; j++){
            printf("%d ", get_elem(M, i,j));
        }
        printf("\n");
    }
}

//transpose the matrix M
struct matrix transpose(struct matrix M){
    struct matrix T;
    T.numrows = M.numcols;
    T.numcols = M.numrows;
    T.elements = (int *)malloc(T.numrows * T.numcols * sizeof(int));
    for (int i = 0; i < T.numrows; i++){
        for (int j = 0; j < T.numcols; j++){
            set_elem(T, i, j, get_elem(M, j, i));
        }
    }
    return T;
}

void main(){
    
    //construct matrix A using stack array. 
    int array1[] = {1,2,3,4,5,6};
    struct matrix A = {2, 3, array1};

    // test the get_elem + print functions
    print(A);
    printf("------------------\n");

    // TODO: uncomment the section below to test the set_elem function
    set_elem(A, 0, 0, 10);
    print(A);
    printf("------------------\n");

    // TODO: construct matrix B using stack array. 
    // follow the example above. 
    int array2[] = {1,2,3,4,5,6};
    struct matrix B = {3, 2, array2};

    // TODO: uncomment the section below to test matrix multiplication
    int array3[] = {0,0,0,0,0,0};
    struct matrix C = {2, 2, array3};
    mult(A, B, C); //    // C = A*B
    // print the result
    print(C);
    // should be 
    // 31 46
    // 49 64
    printf("------------------\n");

    // TODO: uncomment the section below to test the transpose function
    // transpose matrix A
    struct matrix AT = transpose(A);
    print(AT); // print the result
    free(AT.elements);
}