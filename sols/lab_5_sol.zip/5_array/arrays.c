#include <stdio.h>

void main()
{
    // declare an 100 element array of integers
    int array[100];
    int a[10];
    for(int i = 0; i < 10; i = i+1){
        a[i] = i+1;
    }
    //print out array a
    for (int i = 0; i < 10; i++)
    {
        printf("%d ", a[i]);
    }
}