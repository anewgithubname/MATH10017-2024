#include <stdio.h>
#include <math.h> // This is needed for using the sin/cos function

// write your code here