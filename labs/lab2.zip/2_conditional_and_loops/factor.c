#include <stdio.h>

void main(){
    int num = 9*4*3; 

    //modulo operator is %
    printf("remainder of 4/4 is %d\n", 4%4); 
    printf("remainder of 4/3 is %d\n", 4%3); 

    // write an if-else-if ladder below 
   
}