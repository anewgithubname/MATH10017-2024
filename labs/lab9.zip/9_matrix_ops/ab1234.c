#include <stdio.h>
#include <stdlib.h>

// previous lab
// matrix structure definition
struct matrix {
    int numrows; // number of rows
    int numcols; // number of columns
    int *elements; // pointer to the elements stored in row-major order
};

// previous lab
// obtain the element at row i and column j
// input: matrix M, row i, column j
// output: element at row i and column j
int get_elem(struct matrix M, int i, int j){
    return M.elements[i*M.numcols + j];
}

// previous lab, printing matrix M
// input: matrix M
void print(struct matrix M){
    for (int i = 0; i < M.numrows; i ++){
        for (int j = 0; j < M.numcols; j++){
            printf("%d ", get_elem(M, i,j));
        }
        printf("\n");
    }
}

// TODO: write the function set_elem
// assign value v to the element at row i and column j 
// input: matrix M, row i, column j, value v
// output: none
void set_elem(struct matrix M, int i, int j, int v){
    // write your code here
}

// TODO: write a function that performs matrix multiplication
// input: matrix A, matrix B, matrix C
// It computes C = A*B
void mult(struct matrix A, struct matrix B, struct matrix C){
   // write your code here
}

//TODO: write a function transpose the matrix M
// input: matrix M. 
// output: the transpose of M. 


void main(){
    
    //construct matrix A using stack array. 
    int array1[] = {1,2,3,4,5,6};
    struct matrix A = {2, 3, array1};

    // test the get_elem + print functions
    print(A);
    printf("------------------\n");

    // TODO: uncomment the section below to test the set_elem function
    // set_elem(A, 0, 0, 10);
    // print(A);
    // printf("------------------\n");

    // TODO: construct matrix B using stack array. 
    // follow the example above. 

    // TODO: uncomment the section below to test matrix multiplication
    // int array3[] = {0,0,0,0,0,0};
    // struct matrix C = {2, 2, array3};
    // mult(A, B, C); //    // C = A*B
    // // print the result
    // print(C);
    // // should be 
    // // 31 46
    // // 49 64
    // printf("------------------\n");

    // TODO: test your matrix transposition function here 

}