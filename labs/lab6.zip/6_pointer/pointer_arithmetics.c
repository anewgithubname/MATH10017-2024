  #include <stdio.h>
  void main(){
      double a = 0; 
      double *pa = &a;
      double *pa_plus_one = pa + 1;

      printf("pa is %p.\n", pa);
      printf("pa + 1 is %p.\n", pa_plus_one);

  }