#include<stdio.h>
#include<stdlib.h> 
void main(){
    int len = 10, count = 0;
    //start with some provisional heap memory
    int *pratings =  malloc(len*sizeof(int)); 
    while(1){//loop forever until reach "break" statement.
        printf("How do you feel about our service?\n");
        printf("input rating 0-5, type secret code to quit.\n");
        int rating=0; scanf("%d", &rating);

        if(rating == 1234){break;} //end loop
        // expand the array if we have reached the max capacity
        if(count == len){
            pratings = realloc(pratings, (len + 10)*sizeof(int)); 
            len = len + 10;
        }
        pratings[count] = rating;
        count++;
    }
    //compute average ratings and display

    free(pratings);
}