#include <stdio.h>
struct student{
    int ID;
    char *name;
    int grade;
}; //Define a structure before you use it!! 

//TODO: define a function that takes a student struct and prints out the student's info

//TODO: define a function that takes an array of student structs and prints out the info of students who have a grade > 40
// one student per line. 

void main(){
    struct student song; //declare a student variable
    //initialize
    song.ID = 1024; 
    song.name = "song liu";
    song.grade = 70; 

    printf("%s\n", song.name); //displays "song liu"
    
    //declare + initialize in one line. 
    struct student song2 = {1024, "song liu", 70};

    printf("%s\n", song2.name); //displays "song liu"


    //TODO: test your print function here. 
    
}