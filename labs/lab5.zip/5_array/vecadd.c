#include <stdio.h>
void main(){
    //declare and initialize array a and b. 
    double a[] = {1.0, 2.0, 3.0}, 
           b[] = {2.0, 3.0, 4.0};
    double c[3];
    //addition
    for(int i = 0; i< 3; i=i+1){
        c[i] = a[i] + b[i];
    }
    //display each element in the array c
    for(int i = 0; i< 3; i=i+1){
        printf("%f\n", c[i]);
    }
}